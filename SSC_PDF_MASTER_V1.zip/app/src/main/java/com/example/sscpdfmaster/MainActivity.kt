package com.example.sscpdfmaster

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import android.graphics.Color

class MainActivity : Activity() {
    private val subjects = listOf("E|English", "GS|GS / GK", "R|Reasoning", "M|Maths")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        home()
    }
    private fun home() {
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(24,40,24,24) }
        val title=TextView(this).apply { text="📚\nSSC PDF MASTER"; textSize=28f; gravity=1; setTextColor(Color.rgb(20,60,110)); setPadding(0,0,0,40) }
        root.addView(title)
        subjects.forEach { s ->
            val p=s.split("|")
            val b=Button(this).apply { text="${p[0]}    ${p[1]}"; textSize=19f }
            b.setOnClickListener { subject(p[0],p[1]) }
            root.addView(b, LinearLayout.LayoutParams(-1,130).apply{setMargins(0,8,0,8)})
        }
        setContentView(root)
    }
    private fun subject(code:String,name:String) {
        val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(24,30,24,24) }
        val head=TextView(this).apply { text="$code — $name"; textSize=26f; setTextColor(Color.rgb(20,60,110)) }
        root.addView(head)
        val info=TextView(this).apply { text="\nChapter-wise PDFs यहाँ जोड़ें"; textSize=18f }
        root.addView(info)
        val add=Button(this).apply{text="+ Add PDF"}
        root.addView(add)
        add.setOnClickListener { choosePdf() }
        val back=Button(this).apply{text="← Home"}
        root.addView(back)
        back.setOnClickListener { home() }
        setContentView(root)
    }
    private fun choosePdf() {
        val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type="application/pdf"; addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(i,101)
    }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==101 && resultCode==RESULT_OK) {
            val uri=data?.data ?: return
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch(_:Exception){}
            Toast.makeText(this,"PDF added: ${uri.lastPathSegment}",Toast.LENGTH_LONG).show()
            val view=Intent(Intent.ACTION_VIEW).apply { setDataAndType(uri,"application/pdf"); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            startActivity(view)
        }
    }
}
